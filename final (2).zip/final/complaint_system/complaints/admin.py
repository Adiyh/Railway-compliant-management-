from django.contrib import admin
from .models import Complaint,Feedback

admin.site.register(Complaint)
admin.site.register(Feedback)
