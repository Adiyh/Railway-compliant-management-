from flask import Flask, render_template, request, redirect, url_for, flash
from forms import ComplaintForm

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# In-memory data store
complaints = []
users = {}  # Example: {'user_id': {'name': 'John', 'pnr': '123456'}} 

@app.route('/')
def index():
    return render_template('index.html', complaints=complaints)

@app.route('/submit_complaint', methods=['GET', 'POST'])
def submit_complaint():
    form = ComplaintForm()
    if form.validate_on_submit():
        complaint = {
            'name': form.name.data,
            'pnr': form.pnr.data,
            'description': form.description.data
        }
        complaints.append(complaint)
        flash('Complaint submitted successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('complaint.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)
